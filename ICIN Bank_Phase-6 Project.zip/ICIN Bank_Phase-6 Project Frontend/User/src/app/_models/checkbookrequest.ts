export class CheckBookRequest{
   
   accNo:string;
   pages:string;
    
}